const colors = require('tailwindcss/colors')

module.exports = {
  content: [
    './src/index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  safelist: [
    'bg-gray-100', 'bg-white', 'rounded-lg', 'shadow-lg',
    'text-2xl', 'text-gray-800', 'px-4', 'py-2', 'w-full',
    'border', 'border-gray-300', 'focus:ring-2', 'focus:ring-green-500',
    'bg-green-600', 'hover:bg-green-700', 'text-white', 'font-semibold',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#2f855a',
        green: colors.green,
      },
    },
  },
  plugins: [],
}
